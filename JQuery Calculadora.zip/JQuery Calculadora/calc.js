    /*
    * Implement all your JavaScript in this file!
    */
    desabilitar()

    var conteudo =  $("#display").val()
    

        function desabilitar()
        {
            $("#addButton").prop('disabled', true)
            $("#subtractButton").prop('disabled', true)
            $("#divideButton").prop('disabled', true)
            $("#multiplyButton").prop('disabled', true)
        }
       
            function habilitar()
            {
                $("#addButton").prop('disabled', false)
                $("#subtractButton").prop('disabled', false)
                $("#divideButton").prop('disabled', false)
                $("#multiplyButton").prop('disabled', false)
            }
        



    


            
    
        function mostrar(num)   
        {
        var conteudo = $("#display").val()
        $("#display").val("" + conteudo + num)
        }
    
        $("#addButton").click(function() {
        var conteudo = $("#display").val()
        $("#display").val(conteudo + "+")
    desabilitar()
        })

        $("#subtractButton").click(function(){
            var conteudo = $("#display").val()
            $("#display").val(conteudo + "-")
    desabilitar()
            })

        $("#divideButton").click(function (){
            var conteudo = $("#display").val()
            $("#display").val(conteudo + "/")
    desabilitar()
        })

        $("#multiplyButton").click(function (){
            var conteudo = $("#display").val()
            $("#display").val(conteudo + "*")
    desabilitar()
        })

    

    


$("#button1").click(function(){
    mostrar(1)
    habilitar()
}),

$("#button2").click(function(){
    mostrar(2)
    habilitar()
}),

$("#button3").click(function(){
    habilitar()
    mostrar(3)
}),

$("#button4").click(function(){
    habilitar()
    mostrar(4)
}),

$("#button5").click(function(){
    habilitar()
    mostrar(5)
}),

$("#button6").click(function(){
    habilitar()
    mostrar(6)
}),

$("#button7").click(function(){
    habilitar()
    mostrar(7)
}),

$("#button8").click(function(){
    habilitar()
    mostrar(8)
}),

$("#button9").click(function(){
    habilitar()
    mostrar(9)
}),

$("#button0").click(function(){
    habilitar()
    mostrar(0)
}),

$('#clearButton').click(function() {
    $('#display').val(null);
    desabilitar()
});

$("#equalsButton").click(function()
{
    $("#display").val(eval($("#display").val()))
    habilitar()
})





